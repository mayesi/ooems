﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using billing;

namespace ems_billing_TEST
{
    class Program
    {
        static void Main(string[] args)
        {
            string recall = "";
            bool success = true;
            try
            {

                if (Billing.AddBillingCode(System.DateTime.Today.ToShortDateString(), "A003", "1234567890AB", 'M') == false)
                {
                    Console.WriteLine("Invalid Billing Code.\n");
                    success = false;
                }
            }
            catch (Billing.BillingRecallException ex)
            {
                recall = ex.Message;
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
                success = false;
            }
            finally
            {
                // Display if the code was successfully done
                if (success == true)
                {
                    Console.WriteLine("Success\n");
                    // billing code success, recall thrown
                    if (recall != "")
                    {
                        Console.WriteLine("Recall in " + recall + "\n");
                        Console.ReadKey(true);
                    }
                }
            }
        }
    }
}



