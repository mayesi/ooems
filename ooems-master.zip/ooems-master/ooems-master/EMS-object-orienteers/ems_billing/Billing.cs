﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Support;


namespace billing
{
    /// <summary>
    /// This class handles billing related functions in the EMS, such as producing
    /// database records and the UI. In particular, it interacts with the Menu and 
    /// Database classes. Exceptions are thrown for file IO, database, and parameter
    /// errors.
    /// </summary>
    class Billing
    {
        // learn how to build a class in C#
        // learn how to create different getters and setters
        // 

        // Private Data Members
        
        private string Month { get; set; } /// The month for the record to be kept in 
        // For Billing File
        private string DateOfAppointment { get; set; } /// The date of the appointment
        private string HealthCardNumber { get; set; } /// the HCN of the patient
        private char Gender { get; set; } /// this contains the persons gender
        private string BillingCode { get; set; } /// This contains the billing code for the visit
        private string Fee { get; set; } /// This will contain the fee for the visit

        //For Reconcile File
        private string Response { get; set; } /// This will contain the response for the response code for this billing entry


        /// <summary>
        /// This method adds a billing code to a record and stores that record in
        /// the Billing database.
        /// </summary>
        /// <remarks>
        /// This method gets the billing information from the patient database needed,
        /// and the fee from the master file associated with that code. It then adds
        /// that record into a billing records database.
        /// </remarks>
        /// <param name="Date"> visit date </param>
        /// <param name="Code"> billing code </param>
        /// <param name="HCN"> health card number </param>
        public static bool AddBillingCode(string Date, string Code, string HCN, char gender)
        {

            string fullstring = "";


            fullstring = FileSupport.FindLineByBytes("BillingFiles/masterbilling.txt", Code, 4);

            if (fullstring == "")
            {
                return false;
            }
            else
            {
                string smoney = fullstring.Substring(12);

                //This is to be comented out if the date arrives in the correct format, otherwise use it
                string normalized;
                string month;
                datebuilder(Date, out normalized, out month);

                Billing BillingEntry = new Billing(month, normalized, HCN, gender, Code, smoney);

                //Billing record made
                BillingEntry.GenerateMonthlyBillRecord();





                Console.WriteLine("Flag for recall in? y/n\n");
                char key = Console.ReadKey(true).KeyChar;

                if (key == 'y')
                {
                    Console.Clear();
                    Console.WriteLine("Flag for recall in?");
                    Console.WriteLine("1. 1 week \n2. 2 weeks\n3. 3 weeks\n");
                    bool switchcond = false;

                    while (switchcond == false)
                    {
                        key = Console.ReadKey(true).KeyChar;
                        
                        switch (key)
                        {
                            case '1':
                                {
                                    throw new BillingRecallException(string.Format("1 week"));
                                }
                            case '2':
                                {
                                    throw new BillingRecallException(string.Format("2 weeks"));
                                }
                            case '3':
                                {
                                    throw new BillingRecallException(string.Format("3 weeks"));
                                }
                            default:
                                {
                                    Console.Clear();
                                    Console.WriteLine("Flag for recall in?\n");
                                    Console.WriteLine("1. 1 week \n2. 2 weeks\n3. 3 weeks\n");
                                    break;
                                }
                        }
                    }
                }
                 return true;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <param name="normalized"></param>
        /// <param name="monthName"></param>
        private static void datebuilder(string date, out string normalized, out string monthName)
        {
            normalized = "";
            string day = "";
            string month = "";
            string year = "";
            monthName = "";

            month = date.Substring(0, 2);
            if (month.Length < 2)
            {
                month = "0" + month;
            }
            monthName = getMonthName(month);
            int daypos = date.IndexOf('/');
            day = date.Substring(daypos+1,2);
            if (day.Contains("/"))
            {
                day = day.Substring(0, 1);
                day = "0" + day;
            }
            int yearpos = date.LastIndexOf('/');
            year = date.Substring(yearpos+1);
            normalized = year + month + day;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="month"></param>
        /// <returns></returns>
        public static string getMonthName(string month)
        {
            int mm = int.Parse(month);
            string monthName = "";
            switch (mm)
            {
                case 1:
                    {
                        monthName = "January";
                        break;
                    }
                case 2:
                    {
                        monthName = "Febuary";
                        break;
                    }
                case 3:
                    {
                        monthName = "March";
                        break;
                    }
                case 4:
                    {
                        monthName = "April";
                        break;
                    }
                case 5:
                    {
                        monthName = "May";
                        break;
                    }
                case 6:
                    {
                        monthName = "June";
                        break;
                    }
                case 7:
                    {
                        monthName = "July";
                        break;
                    }
                case 8:
                    {
                        monthName = "August";
                        break;
                    }
                case 9:
                    {
                        monthName = "September";
                        break;
                    }
                case 10:
                    {
                        monthName = "October";
                        break;
                    }
                case 11:
                    {
                        monthName = "November";
                        break;
                    }
                case 12:
                    {
                        monthName = "December";
                        break;
                    }
                default:
                    throw new ArgumentException(string.Format("Invalid month"));
            }
            return monthName;
        }


        /// <summary>
        /// Parses out the response from the billing summary.
        /// </summary>
        /// <param name="billingRecord">the record</param>
        /// <returns> the response code is returned  </returns>
        public string ParseReconcileEntry(string billingRecord)
        {
            string responseCode = "";
            return responseCode;
        }


         override public string ToString()
        {
            string thisstring = "";

            thisstring = DateOfAppointment + HealthCardNumber + Gender.ToString() + BillingCode + Fee;

            return thisstring;
        }



        /// <summary>
        /// Parses the billing record database, and pulls all of the records into a single monthly bill.
        /// </summary>
        /// <param name="month"> month for the bill to be made</param>
        private void GenerateMonthlyBillRecord()
        {
            string filename = "BillingFiles/MonthlyBills/"+DateOfAppointment.Substring(0, 4) + "_" +Month+".txt";
            FileSupport.WriteLine(filename, this.ToString());
        }


        /// <summary>
        /// Parses the master billing file for the fee associated with the code in question.
        /// </summary>
        /// <param name="code">The </param>
        /// <returns>The Fee of the master billing file</returns>
        public double ParseMasterBillingFile(string code)
        {
            double fee = 00.00;

            return fee;
        }
        
        ///<summary>
        /// Default constructor for the billing class
        ///</summary>
        Billing()
        {
            Month = "";
            DateOfAppointment = "";
            HealthCardNumber = "";
            Gender = 'U';
            BillingCode = "";
            Fee = "00000000000";
            Response = "";
        }



        /// <summary>
        /// Constructor for generating a billing Object without response code.
        /// </summary>
        /// <param name="BMonth">Billed Month</param>
        /// <param name="DoA">Date of Appointment</param>
        /// <param name="HCN">Health Card Number</param>
        /// <param name="BGender">Gender of the patient</param>
        /// <param name="BC">Billing Code</param>
        /// <param name="BFee">Billed Fee</param>
        Billing(string BMonth, string DoA, string HCN, char BGender, string BC, string BFee)
        {
            Month = BMonth;
            DateOfAppointment = DoA;
            HealthCardNumber = HCN;
            Gender = BGender;
            BillingCode = BC;
            Fee = BFee;
            Response = "";
        }



        /// <summary>
        /// Constructor for generating a billing Object with response code.
        /// </summary>
        /// <param name="BMonth">Billed Month</param>
        /// <param name="DoA">Date of Appointment</param>
        /// <param name="HCN">Health Card Number</param>
        /// <param name="BGender">Gender of the patient</param>
        /// <param name="BC">Billing Code</param>
        /// <param name="BFee">Billed Fee</param>
        /// <param name="Reconcile">The Response code from the goverment</param>
        Billing(string BMonth, string DoA, string HCN, char BGender, string BC, string BFee, string Reconcile)
        {
            Month = BMonth;
            DateOfAppointment = DoA;
            HealthCardNumber = HCN;
            Gender = BGender;
            BillingCode = BC;
            Fee = BFee;
            Response = Reconcile;
        }



        /// <summary>
        /// This method provides the user interface for the Billing class.
        /// </summary>
        public void BillingUI()
        {

        }



        public class BillingRecallException : Exception
        {
            public BillingRecallException(string message)
               : base(message)
            {
            }
        }
    }
}
