﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingUI
{
    class Program
    {
        public const int newPariant = 49;
        public const int newPatiantWC = 50;
        public const int schMenu = 51;
        public const int billMenu = 52;
        public const int quit = 53;
        static void Main(string[] args)
        {
            //starting menu
            bool run = true;
            Console.Title ="ESM";
            Console.ForegroundColor = ConsoleColor.Green;
            int userInput = 0;
            Menu mu = new Menu();
            Schedule sch = new Schedule();

            while (run)
            {
                userInput = mu.mainMenu();
                Console.Clear();
                switch(userInput)
                {
                    case newPariant:
                        
                        break;
                    case newPatiantWC:                     
                        
                        break;
                    case schMenu:
                        
                        sch.period();
                        break;
                    case billMenu:
                        mu.billingMenu();
                        break;
                    case quit:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.Write("Please select an option between 1-5");
                        break;
                }

            }
            



        }
    }
}
